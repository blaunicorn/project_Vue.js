<template>

    <h1>page 2</h1>
</template>

<script>


</script>

<style scoped>

</style>